package classes.interfaces;

import java.io.IOException;

public interface IDownloaderService {
    void Download(String source);
}
