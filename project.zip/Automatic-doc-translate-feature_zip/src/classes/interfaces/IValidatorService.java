package classes.interfaces;

public interface IValidatorService {
    boolean validate(String source);
}
