package classes.interfaces;

public interface IWriterService {
    void Write(String source, String destination);
}
